/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { HighlightSearchPipe } from './highlight-search.pipe';

describe('Pipe: HighlightSearche', () => {
  it('create an instance', () => {
    let pipe = new HighlightSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
