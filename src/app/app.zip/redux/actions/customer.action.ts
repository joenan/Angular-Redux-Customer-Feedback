import { Customer } from './../models/customer.model';
import { createAction, props } from "@ngrx/store";


export const ADD_CUSTOMER_ACTION = "[customer page] add customer";
export const UPDATE_CUSTOMER_ACTION = "[customer page] update customer"
export const DELETE_CUSTOMER_ACTION = "[customer page] delete customer"
export const ADD_CUSTOMER_FEEDBACK_ACTION = "[customer page] add customer feedback"

export const addCustomer = createAction(ADD_CUSTOMER_ACTION, props<{ customer: Customer }>())

export const updateCustomer = createAction(UPDATE_CUSTOMER_ACTION, props<{ customer: Customer }>())

export const deleteCustomer = createAction(DELETE_CUSTOMER_ACTION, props<{ id: any }>())

export const addCustomerFeedback = createAction(ADD_CUSTOMER_FEEDBACK_ACTION, props<{ customer: Customer }>())
