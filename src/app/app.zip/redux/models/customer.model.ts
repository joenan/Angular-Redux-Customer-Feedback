import { Feedback } from './feedback.model.ts';
export class Customer {
  id: any;
  name: string = '';
  feedback?: any
}
