export class Feedback {
  id: any
  feedback: string = ''
}
