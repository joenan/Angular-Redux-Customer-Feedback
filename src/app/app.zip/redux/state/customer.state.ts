import { Customer } from './../models/customer.model';

export interface CustomerState {
  customers: Customer[]
}

export const initialCustomersState: CustomerState = {
  customers: [
    {
      id: "1", name: "Austin",
      feedback: [
        { id: "1", feedback: "It is working" },
        { id: "2", feedback: "Error" }
      ]
    },
    {
      id: "2", name: "Victor",
      feedback: [
        { id: "1", feedback: "life na Hustle" },
        { id: "2", feedback: "Saved" },
        { id: "3", feedback: "Error" }
      ]
    },
    {
      id: "3", name: "James",
      feedback: [
        { id: "1", feedback: "alawee" },
        { id: "2", feedback: "yahoo" }
      ]
    },
    {
      id: "4", name: "Adebayor",
      feedback: [
        { id: "1", feedback: "It is not funny at all" },
        { id: "2", feedback: "luna is a goal" },
        { id: "3", feedback: "friends" }
      ]
    },

  ]
}
