import { addCustomer, addCustomerFeedback, deleteCustomer, updateCustomer } from './../actions/customer.action';
import { initialCustomersState } from './../state/customer.state';
import { createReducer, on } from "@ngrx/store"



const _customerReducer = createReducer(initialCustomersState,
  on(addCustomer, (state, action) => {
    let customer = { ...action.customer }
    customer.id = (state.customers.length + 1).toString()
    console.log(customer)
    return {
      ...state,
      customers: [...state.customers, customer]
    }
  }), on(updateCustomer, (state: any, action: any) => {
    const updateCustomers = state.customers.map((customer: any) => {
      return action.customer.id === customer.id ? action.customer : customer
    })
    return {
      ...state,
      customers: updateCustomers
    }
  }), on(deleteCustomer, (state: any, id: any) => {
    const updatedCustomerList = state.customers.filter((customer: any) => {
      return customer.id !== id.id
    })
    return {
      ...state,
      customers: updatedCustomerList
    }
  }), on(addCustomerFeedback, (state: any, action: any) => {
    console.log(action);
    console.log(state);
    // const addCustomerFeedbacks = state.customers.map((customer: any) => {
    //   return action.id === customer.id ? action.feedback : customer.feedback
    // })

    // console.log(action);

    // console.log(addCustomerFeedbacks);
    // console.log(action.feedback);
    var customerFeedback = action.feedback
    console.log(customerFeedback)



    return {
      ...state,
      customers: {
        feedback: customerFeedback
      }
    }
  })

)

export function customersReducer(state: any, action: any) {
  return _customerReducer(state, action)
}
