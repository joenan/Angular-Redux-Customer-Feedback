import { CustomerState } from './../state/customer.state';
import { createFeatureSelector, createSelector } from "@ngrx/store"

const getCustomersState = createFeatureSelector<CustomerState>('customers')


export const getCustomers = createSelector(getCustomersState, (state: any) => {
  return state.customers
})

export const getCustomerById = createSelector(getCustomersState, (state: any, props: any) => {
  return state.customers.find((customer: any) => customer.id === props.id)
})
