import { ToastrModule, ToastrService } from 'ngx-toastr';
import { getCustomers } from './../../redux/selectors/customer.selector';
import { AppState } from './../../shared/app.state';
import { Feedback } from './../../redux/models/feedback.model.ts';

import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { select, Store } from '@ngrx/store';
import { Customer } from 'src/app/redux/models/customer.model';
import { ToastService } from 'angular-toastify';
import { addCustomer, addCustomerFeedback } from 'src/app/redux/actions/customer.action';

@Component({
  selector: 'app-customer-feedback',
  templateUrl: './customer-feedback.component.html',
  styleUrls: ['./customer-feedback.component.css']
})
export class CustomerFeedbackComponent implements OnInit {
  p = 1
  searchfilter: any
  feedbacksearchfilter: any
  customerList: Observable<Customer[]> | any
  feedbackList: Observable<Feedback[]> | any
  customer: any = "";
  showCustForm: boolean = false
  showFeedForm: boolean = false
  feedback: any = ""
  customerFeedbackList: any = [];
  currentCustomerName: any;
  customerIdToUpdate: any;
  customerToUpdate: any;

  constructor(private store: Store<AppState>, private toastr: ToastrService,) { }

  ngOnInit() {
    this.customerList = this.store.select(getCustomers)


  }


  addCustomer() {
    if (this.customer == '') {
      this.toastr.error("", "Please fill a Customer")
      return
    }

    const customer: Customer = {
      id: 0,
      name: this.customer,
      feedback: []
    }
    this.store.dispatch(addCustomer({ customer }))
    this.showCustForm = false
    this.toastr.success('', "Customer Created")

  }



  showCustomerForm() {
    this.showCustForm = true
  }

  showFeedBackForm() {
    this.showFeedForm = true
  }

  getCustomerFeedback(list: any) {
    this.customerFeedbackList = list.feedback
    this.currentCustomerName = list.name
    // this.customerIdToUpdate = list.id
    this.customerToUpdate = list
    console.log(list);



  }

  addNewCustomerFeedback() {
    var customer = this.customerToUpdate

    var id = (customer.feedback.length + 1).toString()
    var newFeedbackFromUi = {
      id: id,
      feedback: this.feedback
    }
    console.log(newFeedbackFromUi);

    // this.customerToUpdate.feedback.push(newFeedbackFromUi)

    var feedback = [...this.customerToUpdate.feedback, newFeedbackFromUi]
    console.log(feedback);

    this.store.dispatch(addCustomerFeedback(Object.assign({}, this.customerToUpdate, {
      feedback: feedback
    })));
    console.log(this.customerToUpdate);
    this.showFeedForm = false
    // this.store.dispatch(addCustomerFeedback({ feedback }))
    // var customer: any = this.customerList.find((x: any) => x.name == this.currentCustomerName);

    // console.log(customer);

    // var newt = this.customerList.filter((x: any) => x.name != this.currentCustomerName)
    // console.log(newt);
    // var newobj = [...customer.feedback, newFeedbackFromUi]
    // console.log(newobj);

    // const filteredItems = this.customerList.filter((x: any) => x.name !== this.currentCustomerName - 1)


    // this.store.dispatch(new AddCustomer(Object.assign({}, customer, {
    //   feedback: newobj
    // })));



    // this.customerList = newt
    // console.log(this.customerList);




    // customer.feedback = newobj

    // console.log(newobj);
    // console.log(customer)
    // var updatedCustomerFeedback = newobj

    // const newCustomer = new Customer
    // newCustomer.name = customer.name
    // newCustomer.feedback = newobj

    // this.store.dispatch(new AddCustomer(newCustomer))
    // console.log(customer);
    // console.log(this.customerIdToUpdate);

  }

}
