import { customersReducer } from '../redux/reducers/customer.reducer';
import { CustomerState } from './../redux/state/customer.state';

export interface AppState {
  customers: CustomerState
}

export const appReducer = {
  customers: customersReducer
}
